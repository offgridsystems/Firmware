/*
 * dkboards.c
 *
 *  Created on: Feb 16, 2021
 *      Author: Tim Economu
 *
 *
 *
 *
 *
 *   Date       Ver     Who     Was/IS
 *
 *   5MAR2021   000     TBE     Created for V2 DKblock hardware using CC1310 Launcpad and RF node and concentrator (using CC13152P-2 dev kit as concentrator)
 *
 */

#include "dkboards.h"
#include <sce/scif.h>
#include <ti/devices/DeviceFamily.h>
#include DeviceFamily_constructPath(driverlib/aux_adc.h)
#include <ti/drivers/ADC.h>     // Import ADC Driver definitions



void ADC_calibration(void) {        // go get two values (Vcell hi (7.4V node) and Vcell lo, and dirive 3.7V hi side and 3.7V low side values

    int32_t adcOffset = AUXADCGetAdjustmentOffset(AUXADC_REF_FIXED);
    int32_t adcGainError = AUXADCGetAdjustmentGain(AUXADC_REF_FIXED);
    int32_t adcValue1, adcCorrectedValue, adcValueMicroVolt;

        // Read ADC value - 7.4V side of block
        adcValue1 = scifTaskData.adcSample.output.adcValue;
        // Correct ADC raw value and calibrate gain and offset
        adcCorrectedValue = AUXADCAdjustValueForGainAndOffset((int32_t) adcValue1, adcGainError, adcOffset);
        // Convert ADC value to Millivolts.
        adcValueMicroVolt = (AUXADCValueToMicrovolts(AUXADC_FIXED_REF_VOLTAGE_NORMAL,adcCorrectedValue))/1000;        // save uV result into an 16b global for mV usage
        resultMv_HI = (uint16_t) adcValueMicroVolt;      // cast to 16b -range check...should always be lower than 4000000
        resultMv_HI = resultMv_HI * 3.569400;      // adjust for resistor divider scaling

        // Read ADC value - 3.7V side of block
        adcValue1 = scifTaskData.adcSample.output.adcNew;
        // Correct ADC raw value
        adcCorrectedValue = AUXADCAdjustValueForGainAndOffset((int32_t) adcValue1, adcGainError, adcOffset);
        // Convert ADC value to Millivolts.
        adcValueMicroVolt = (AUXADCValueToMicrovolts(AUXADC_FIXED_REF_VOLTAGE_NORMAL,adcCorrectedValue))/1000;
        resultMv_LO = (uint16_t) adcValueMicroVolt;
        resultMv_LO = resultMv_LO * 2.0017;     // adjust for resistor divider scaling

        // and now get other ADC values while you are here
        latestCapSwitchHit = scifTaskData.adcSample.output.adcCap;      // cap switch value
    }

void NTC_Thermistor_testing(void) {
    uint16_t tempvalue = 0 ;
    //static uint16_t HistOpenNTC ;

    numOpenNTC = 0 ;   // ignore 1 open or ...

    uint16_t static Tcoldest = AMBIENT_TEMP;   // coldest sensor in the block (ignore only one open ntc per block)
    uint16_t static Thottest = AMBIENT_TEMP;    // init with ambient temp = 25C


    // Read all NTC thermistors and find hottest and coldest
    // remember lower is hotter (Negative Temperature Coeff Thermistor - NTC)
    tempvalue = scifTaskData.adcSample.output.adcTemp0;         // 1st thermistor = amb temp
       if (tempvalue >= OPEN_NTC) {  // NOTE TIM CALIBRATE THIS VALUE FOR 4.1V ref
          numOpenNTC++ ;               // ignore first open ntc, - don't stop working because of one broken NTC
       }
       else {
           Tcoldest = tempvalue;
           Thottest = tempvalue;    // first pass set hi and low to amb temp sample
       }
       if (Thottest > tempvalue)  Thottest = tempvalue ;

       tempvalue = scifTaskData.adcSample.output.adcTemp1;         // 2nd thermistor
       if (tempvalue >= OPEN_NTC) {
           numOpenNTC++ ;               // ignore first open ntc, - don't stop working because of one broken NTC
           if (numOpenNTC >= 2) Tcoldest = tempvalue;   // if second "open" NTC don't ignore...maybe its just really really cold!!
       }
       else {
            if (Tcoldest < tempvalue) Tcoldest =  tempvalue;   // avg current value
       }
       if (Thottest > tempvalue)  Thottest =  tempvalue ;

       tempvalue = scifTaskData.adcSample.output.adcTemp2;         // 3rd thermistor
       if (tempvalue >= OPEN_NTC) {
           numOpenNTC++ ;               // ignore first open ntc, - don't stop working because of one broken NTC
           if (numOpenNTC >= 2) Tcoldest = tempvalue;   // if second "open" NTC don't ignore...maybe its just really really cold!!
       }
       else {
            if (Tcoldest < tempvalue) Tcoldest =  tempvalue;   // avg current value
       }
       if (Thottest > tempvalue)  Thottest =  tempvalue ;

       tempvalue = scifTaskData.adcSample.output.adcTemp3;         // 4nd thermistor
       if (tempvalue >= OPEN_NTC) {
           numOpenNTC++ ;               // ignore first open ntc, - don't stop working because of one broken NTC
           if (numOpenNTC >= 2) Tcoldest = tempvalue;   // if second "open" NTC don't ignore...maybe its just really really cold!!
       }
       else {
            if (Tcoldest < tempvalue) Tcoldest =  tempvalue;   // avg current value
       }
       if (Thottest > tempvalue)  Thottest =  tempvalue ;

       tempvalue = scifTaskData.adcSample.output.adcTemp4;         // 5nd thermistor
       if (tempvalue >= OPEN_NTC) {
           numOpenNTC++ ;               // ignore first open ntc, - don't stop working because of one broken NTC
           if (numOpenNTC >= 2) Tcoldest = tempvalue;   // if second "open" NTC don't ignore...maybe its just really really cold!!
       }
       else {
            if (Tcoldest < tempvalue) Tcoldest =  tempvalue;   // avg current value
       }
       if (Thottest > tempvalue)  Thottest = tempvalue ;

       tempvalue = scifTaskData.adcSample.output.adcTemp5;         // 6nd thermistor
       if (tempvalue >= OPEN_NTC) {
           numOpenNTC++ ;               // ignore first open ntc, - don't stop working because of one broken NTC
           if (numOpenNTC >= 2) Tcoldest = tempvalue;   // if second "open" NTC don't ignore...maybe its just really really cold!!
       }
       else {
            if (Tcoldest < tempvalue) Tcoldest =  tempvalue;   // avg current value
       }
       if (Thottest > tempvalue)  Thottest = tempvalue ;

       tempvalue = scifTaskData.adcSample.output.adcTemp6;         // 7nd thermistor
       if (tempvalue >= OPEN_NTC) {
           numOpenNTC++ ;               // ignore first open ntc, - don't stop working because of one broken NTC
           if (numOpenNTC >= 2) Tcoldest = tempvalue;   // if second "open" NTC don't ignore...maybe its just really really cold!!
       }
       else {
            if (Tcoldest < tempvalue) Tcoldest =  tempvalue;   // avg current value
       }
       if (Thottest > tempvalue)  Thottest =  tempvalue ;

       tempvalue = scifTaskData.adcSample.output.adcTemp7;         // 8nd thermistor
       if (tempvalue >= OPEN_NTC) {
           numOpenNTC++ ;               // ignore first open ntc, - don't stop working because of one broken NTC
           if (numOpenNTC >= 2) Tcoldest = tempvalue;   // if second "open" NTC don't ignore...maybe its just really really cold!!
       }
       else {
            if (Tcoldest < tempvalue) Tcoldest =  tempvalue;   // avg current value
       }
       if (Thottest > tempvalue)  Thottest =  tempvalue ;

       // now convert hottest and coldest NTC to Deg C (-40C offset)
       Hottest_Sensor_DegCoff40 = lookup_DegC(Thottest);
       Coldest_Sensor_DegCoff40 = lookup_DegC(Tcoldest);

       //if (HistOpenNTC >= numOpenNTC)

}




uint8_t lookup_DegC(uint16_t ADC_NTCcounts){    // NTC lookup from -40 to 120C - 160 values REMEMBER that -40 is 0 so there is a +40C offset ON ALL TEMPS
#define TABLE_SIZE 160          // -40 to 119 in 1C steps
#define ADCCOUNTS_at120C   45   // ADC counts at 120C
#define ONEtwenty   160     // set to 120C = max table (with 40C offset)
uint8_t DegC_minus40  = 0;

   static const uint16_t NTC_Table[TABLE_SIZE] = {
                                         // ADC counts              Degrees C - table ends at 120C ( spreadsheet named -NTC thermistor muRata NCP18W104D computations from -40-100C in 1 AND 5 deg steps.ods)
                                                  3007    ,  //   -40
                                                  2997    ,  //   -39
                                                  2987    ,  //   -38
                                                  2976    ,  //   -37
                                                  2964    ,  //   -36
                                                  2952    ,  //   -35
                                                  2939    ,  //   -34
                                                  2926    ,  //   -33
                                                  2912    ,  //   -32
                                                  2897    ,  //   -31
                                                  2881    ,  //   -30
                                                  2865    ,  //   -29
                                                  2847    ,  //   -28
                                                  2829    ,  //   -27
                                                  2810    ,  //   -26
                                                  2791    ,  //   -25
                                                  2770    ,  //   -24
                                                  2748    ,  //   -23
                                                  2726    ,  //   -22
                                                  2702    ,  //   -21
                                                  2678    ,  //   -20
                                                  2653    ,  //   -19
                                                  2627    ,  //   -18
                                                  2600    ,  //   -17
                                                  2572    ,  //   -16
                                                  2543    ,  //   -15
                                                  2513    ,  //   -14
                                                  2482    ,  //   -13
                                                  2451    ,  //   -12
                                                  2418    ,  //   -11
                                                  2385    ,  //   -10
                                                  2351    ,  //   -9
                                                  2316    ,  //   -8
                                                  2281    ,  //   -7
                                                  2244    ,  //   -6
                                                  2207    ,  //   -5
                                                  2170    ,  //   -4
                                                  2132    ,  //   -3
                                                  2093    ,  //   -2
                                                  2054    ,  //   -1
                                                  2015    ,  //   0
                                                  1975    ,  //   1
                                                  1935    ,  //   2
                                                  1894    ,  //   3
                                                  1854    ,  //   4
                                                  1813    ,  //   5
                                                  1772    ,  //   6
                                                  1731    ,  //   7
                                                  1690    ,  //   8
                                                  1650    ,  //   9
                                                  1609    ,  //   10
                                                  1569    ,  //   11
                                                  1528    ,  //   12
                                                  1489    ,  //   13
                                                  1449    ,  //   14
                                                  1410    ,  //   15
                                                  1371    ,  //   16
                                                  1333    ,  //   17
                                                  1295    ,  //   18
                                                  1258    ,  //   19
                                                  1221    ,  //   20
                                                  1185    ,  //   21
                                                  1150    ,  //   22
                                                  1115    ,  //   23
                                                  1081    ,  //   24
                                                  1048    ,  //   25
                                                  1015    ,  //   26
                                                  983 ,  //   27
                                                  952 ,  //   28
                                                  922 ,  //   29
                                                  892 ,  //   30
                                                  863 ,  //   31
                                                  835 ,  //   32
                                                  807 ,  //   33
                                                  780 ,  //   34
                                                  755 ,  //   35
                                                  729 ,  //   36
                                                  705 ,  //   37
                                                  681 ,  //   38
                                                  658 ,  //   39
                                                  635 ,  //   40
                                                  614 ,  //   41
                                                  593 ,  //   42
                                                  572 ,  //   43
                                                  553 ,  //   44
                                                  534 ,  //   45
                                                  515 ,  //   46
                                                  497 ,  //   47
                                                  480 ,  //   48
                                                  464 ,  //   49
                                                  447 ,  //   50
                                                  432 ,  //   51
                                                  417 ,  //   52
                                                  402 ,  //   53
                                                  388 ,  //   54
                                                  375 ,  //   55
                                                  362 ,  //   56
                                                  349 ,  //   57
                                                  337 ,  //   58
                                                  326 ,  //   59
                                                  314 ,  //   60
                                                  304 ,  //   61
                                                  293 ,  //   62
                                                  283 ,  //   63
                                                  273 ,  //   64
                                                  264 ,  //   65
                                                  255 ,  //   66
                                                  246 ,  //   67
                                                  238 ,  //   68
                                                  230 ,  //   69
                                                  222 ,  //   70
                                                  214 ,  //   71
                                                  207 ,  //   72
                                                  200 ,  //   73
                                                  193 ,  //   74
                                                  187 ,  //   75
                                                  181 ,  //   76
                                                  175 ,  //   77
                                                  169 ,  //   78
                                                  163 ,  //   79
                                                  158 ,  //   80
                                                  153 ,  //   81
                                                  148 ,  //   82
                                                  143 ,  //   83
                                                  138 ,  //   84
                                                  134 ,  //   85
                                                  129 ,  //   86
                                                  125 ,  //   87
                                                  121 ,  //   88
                                                  117 ,  //   89
                                                  113 ,  //   90
                                                  110 ,  //   91
                                                  106 ,  //   92
                                                  103 ,  //   93
                                                  100 ,  //   94
                                                  97  ,  //   95
                                                  94  ,  //   96
                                                  91  ,  //   97
                                                  88  ,  //   98
                                                  85  ,  //   99
                                                  82  ,  //   100
                                                  80  ,  //   101
                                                  77  ,  //   102
                                                  75  ,  //   103
                                                  73  ,  //   104
                                                  71  ,  //   105
                                                  68  ,  //   106
                                                  66  ,  //   107
                                                  64  ,  //   108
                                                  62  ,  //   109
                                                  61  ,  //   110
                                                  59  ,  //   111
                                                  57  ,  //   112
                                                  55  ,  //   113
                                                  54  ,  //   114
                                                  52  ,  //   115
                                                  51  ,  //   116
                                                  49  ,  //   117
                                                  48  ,  //   118
                                                  47  ,  //   119
                                               //   45  ,  //   120  - table ends at 120C
                                               //   44  ,  //   121

    };
   uint8_t i;
    for  (i=0; i<=TABLE_SIZE; i++)  {
      if (NTC_Table[i] <= ADC_NTCcounts)  {      //value = NTC_Table[i]
        DegC_minus40  = i;
           i=TABLE_SIZE;
       }
       else {
           if (ADC_NTCcounts <= NTC_Table[TABLE_SIZE-1]) DegC_minus40 = ONEtwenty;   // max table is 160-40=120C so set to 120C      if (ADC_NTCcounts < ADCCOUNTS_at120C)
       }
    }

return(DegC_minus40 );
}





void LED_driver(uint8_t DK_Mode)              // operate the LEDs
{
    //latestHIGHshunt = ON;
    // red light if multiple open NTCs...
    if (numOpenNTC > 3) latestRedLED = ON ;     // turn on red led for 3 or more open NTC
    else latestRedLED = OFF ;


    if (DK_Mode) latestYellowLED= !latestYellowLED;       // toggle led in chg/disch
    // yellow led = fast blink charging
    // yellow led = slow blink = discharging and ON FULL = one side or both in balancing

}



uint8_t FindDK_mode(uint16_t BlockV, uint16_t LowCellV)    {    // test dk  for voltage changes = not sleeping
#define  DELTA_V  15    // in mV, so 15 mV of change is a mode change

    static uint16_t Hist_BlockV;
    //static uint16_t Hist_Loside_CellV;            // deltaV low side not evauated because we have deltaV of whole block
    uint16_t  HighCellV;
    if(LowCellV <= BlockV) HighCellV = BlockV - LowCellV ;        // derive high cell v from block and low cell v

    DK_Mode =  SLEEPING; // default is sleep mode for low power

// test for fast cell V delta = chg/disc
    if ((BlockV - DELTA_V) > Hist_BlockV )
        {
        DK_Mode = CHARGING;      // if new sample value is higher than old, we are charging
        }
        else if ((BlockV + DELTA_V) < Hist_BlockV ){
        DK_Mode = DISCHARGING;   // else if more than 50mv less, we are discharging
    }
 // test for absolute cell V - overrides other tests
    if (HighCellV > VCELL_BALANCE)   DK_Mode = CHARGING;      // Voltage above nominal, must be charging
    if (LowCellV > VCELL_BALANCE)   DK_Mode = CHARGING;      // Voltage above nominal, must be charging

    Hist_BlockV = BlockV;
   // Hist_Loside_CellV = LowCellV;

    // remember ADC can detect DELTA V too, so maybe use that feature to wake up? Maybe when ADC speeds up - that means not sleep mode

    latestHIGHshunt = OFF;
    latestLOWshunt = OFF;

    bool LoFan = OFF;


    // Fan logic
     // Fan turns on when Tcells above 40C, AND below 100C, if charging or discharging.
     if (DK_Mode)   // if non-zero = not sleeping
     {
       if ((Hottest_Sensor_DegCoff40 < NTC_WARM) && (Hottest_Sensor_DegCoff40 > NTC_OVERTEMP)) // if chg/discharging, AND getting warmer AND not too hot...
       {
         if ((HighCellV > VCELL_LVDO_SPEC) &&  (LowCellV > VCELL_LVDO_SPEC))  // AND not low cell voltage, turn on  fan
         {
           LoFan = ON;
         }
       }
     }
     else // sleeping so only if balancing turn on fan
     {
        if (Hottest_Sensor_DegCoff40 < NTC_OVERTEMP)
        {
           if ((HighCellV > VCELL_BALANCE) ||  (LowCellV > VCELL_BALANCE))
            {
            LoFan = ON;
            }
        }
        else FaultMode = NTC_OVERTEMP;
     }
     if (LoFan)  latestFAN = ON;        // actually turn fan on/off here
     else  latestFAN = OFF;



     // Balance and heating (yes you can use them to heat the pack) resistors logic
      // Cells go into balancing above Vcell_nominal if charging
      bool LoShunt = OFF;
      bool HiShunt = OFF;

      if (Hottest_Sensor_DegCoff40 < NTC_OVERTEMP)        // turn on shunts if not overtemp
      {
         if (HighCellV > VCELL_BALANCE) HiShunt = ON;
         if (LowCellV > VCELL_BALANCE) LoShunt = ON;
      }
      else FaultMode = NTC_OVERTEMP;

      // UI - tell the LEDs what state we are in
      if ((HiShunt == ON) || (LoShunt == ON)) {
     //   digitalWrite(LED2green, GLOW);    // light green LED and...
      //  digitalWrite(LED2red, GLOW);    // light red LED if balancing
      }
      else {
      //  digitalWrite(LED2green, DARK);
     //   digitalWrite(LED2red, DARK);
      }

#if BOTTOM_BALANCE
      // another reason for operating the shunts is bottom balance, so
      //if one cell is at 3.0 and the other at 2.8 they will try to balance
      if ((LowCellV < HighCellV) && (LowCellV > VCELL_LVDO_SPEC))  // check loside cell first
      {
        if ((HighCellV > VCELL_LVDO_SPEC) && (HighCellV <= VCELL_LOW_BALANCE))  HiShunt = ON;     // bott balance till Low V spec
        //VERBOSE_PRINT("High side bottom balance");
      }
      else if ((HighCellV < LowCellV) && (HighCellV > VCELL_LVDO_SPEC)) // now check hiside cell
      {
        if ((LowCellV > VCELL_LVDO_SPEC) && (LowCellV <= VCELL_LOW_BALANCE)) LoShunt = ON;
        //VERBOSE_PRINT("Low side bottom balance");
      }

      if (FaultMode != NTC_OVERTEMP) {
          if (HiShunt) latestHIGHshunt = ON;    // actually turn on shunts here
          else if (LoShunt)  latestLOWshunt = ON;       // only one on at a time
      }


#endif

 return(DK_Mode);
 }










