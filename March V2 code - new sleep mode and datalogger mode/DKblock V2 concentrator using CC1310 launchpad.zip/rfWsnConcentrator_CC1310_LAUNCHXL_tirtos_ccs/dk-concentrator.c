/*
 * dkboards.c
 *
 *  Created on: Feb 16, 2021
 *      Author: Tim Economu
 *
 *
 *
 *
 *
 *   Date       Ver     Who     Was/IS
 *
 *   TBD   000     TBE     Released early working version to github
 *   5MAR2021   000     TBE     Created for V2 DKblock hardware using CC1310 Launchpad and RF node and concentrator (using CC13152P-2 dev kit as concentrator)
 *
 */

#include <dk-concentrator.h>
#include <ti/devices/DeviceFamily.h>
//#include DeviceFamily_constructPath(driverlib/aux_adc.h)
//#include <ti/drivers/ADC.h>     // Import ADC Driver definitions







void LED_driver(uint8_t DK_Mode)              // operate the LEDs
{
 //   if (numOpenNTC > 3) latestRedLED = ON ;     // turn on red led for 3 or more open NTC
//    else latestRedLED = OFF ;


//    if (DK_Mode) latestYellowLED= !latestYellowLED;       // toggle led in chg/disch


}








