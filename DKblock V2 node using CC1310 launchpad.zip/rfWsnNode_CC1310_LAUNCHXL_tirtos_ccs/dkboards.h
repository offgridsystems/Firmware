/*
 * dkboards.h
 * Hardware setup and init for DK specific wireless BMS tasks
 *  Created on: Feb 15, 2021
 *      Author: Tim Economu
 */


// define what code is running, DKBLOCK, DK1CELL, or LAUNCHPAD
#define CC1310_LAUNCHPAD 0      // define as non-zero if you wanna compile code
#define DKBLOCK 1
#define DK1CELL 0
#define DK_VERSION 0        // 8 bit var ver 000 to 255...


#if DKBLOCK

#include "Board.h"
#include <ti/drivers/PIN.h>


// generic defines
#define ON  1
#define OFF 0

// I/O port defines
#define LO_FAN_CNTRL    IOID_13   // Future - NOT USED Feb 2021
#define HI_FAN_CNTRL    IOID_14    // only fan drive on board Feb 2021
#define HI_SHUNT_CNTRL  IOID_12        // 7.4V side (high) of block
#define LO_SHUNT_CNTRL  IOID_11        // 3.7V nom side of block
#define GREEN_LED       IOID_6
#define YELLOW_LED      IOID_7
#define RED_LED         IOID_5
#define NODE_ACTIVITY_LED GREEN_LED     // redefine TI code for our green led

// NTC constants (remember ref is 4.1V not 3.3V)
//#define SHORTED_NTC 20;     // ADC counts for 140C - NTC does not fail in this way, so save value
#define OPEN_NTC 3008      // open NTC (or colder than -40C which 3007 ADC counts)
#define AMBIENT_TEMP 1048   // ambient temp of 25C is about 1048 ADC counts
#define NTC_WARM  (35+40)          // 35C +40 offset
#define NTC_OVERTEMP (100+40)           // 100C is getting too hot


// declare BlockMode types - 3 basic modes. Either sleeping most of the time, or CHG or DISCH
#define SLEEPING 0
#define CHARGING  10
#define DISCHARGING  20
#define MODE0 30     // temporary rename when have english names

// cell types and balance methods (top balance is not optional)
#define  LG_MH1 0          // 3200mah
#define  SANYO_NCR18650B 10  // 3400mah  NOTE battery with the --NONZERO-- value will be used
#define  CELLTYPE0 0        //
#define BOTTOM_BALANCE  1           // 0=no bot balance 1= YES bot balance


#if LG_MH1
#define VCELL_HVDO_SPEC 4250        // 4.25V
#define VCELL_BALANCE 4110            // top balance point
#define VCELL_LOW_BALANCE 3000           // if used low balance to lvdo
#define VCELL_LVDO_SPEC 2900        // 2.90
#endif

#if SANYO_NCR18650B
#define VCELL_HVDO_SPEC 4300        // 4.300V = HIGH voltage disconnect
#define VCELL_BALANCE 3900            // top balance point
#define VCELL_LOW_BALANCE 3000           //  if used low balance to lvdo
#define VCELL_LVDO_SPEC 2500        // 2.500
#endif

#if CELLTYPE0
#define Vcell_HVDO_SPEC 4300        // 4.300V
#define VCELL_BALANCE 3900            // top balance point
#define VCELL_LOW_BALANCE 3000           //  if used low balance to lvdo
#define VCELL_LVDO_SPEC 2500        // 2.500
#endif


//uint16_t static const NTClookupTable[];

/* ADC conversion global variables */
uint8_t numOpenNTC ;   // ignore 1 open or ...
uint16_t resultMv_HI;      // calibrated analog value from hi side
uint16_t resultMv_LO;      // calibrated analog value from lo side
uint8_t latestCapSwitchHit;        // 1= YES hit, 0 = NO
uint8_t  Hottest_Sensor_DegCoff40; // ambient +40 deg offset (so that we can measure -40 without using unsigned)
uint8_t  Coldest_Sensor_DegCoff40;   // coldest sensor with 40C offset
uint8_t DK_Mode;        // charge discharge sleep
uint8_t FaultMode;      // overtemp, and NTC open ...more to come

bool latestHIGHshunt;       // value of on or off for high shunt
bool latestLOWshunt;
bool latestFAN;             // value on/off
bool latestRedLED;
bool latestYellowLED;
bool latestGreenLED;



//uint8_t ADC_NTCcounts; //global for now



// function defines
void ADC_calibration(void);                     // get both cell voltages in mv
void NTC_Thermistor_testing(void);              // find hot and coldest temp sensor
uint8_t lookup_DegC(uint16_t ADC_NTCcounts);    // go get deg C +40C offset
void LED_driver(uint8_t DK_Mode);            // operate the LEDs
// use block/cell voltages to determine mode. Incr/decr = chg/discharg. No change = SLEEP ALso run fans and balance resistors
uint8_t FindDK_mode(uint16_t BlockV, uint16_t LowCellV);
#endif
