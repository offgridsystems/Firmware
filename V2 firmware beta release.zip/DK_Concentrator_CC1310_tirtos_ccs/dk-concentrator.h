/*
 * dk-concentrator.h
 * Hardware setup and init for DK specific wireless BMS tasks
 *  Created on: Feb 15, 2021
 *      Author: Tim Economu
 */


// define what code is running, DKBLOCK, DK1CELL, or LAUNCHPAD
//#define CC1310_LAUNCHPAD 0      // define as non-zero if you wanna compile CC1310_LAUNCHPAD code
//#define DKBLOCK 1               // use DKBLOCK to use new DK specific code to make it easy to go back and use new TI code when new SDKs come out
#define DK1CELL 0               // new one cell DK
#define DK_VERSION 255        // Firmware ver 000 to 255...

// ***note to run SPI0 you must turn off DATALOGGER***
#define DATALOGGER_MODE 0   // 0= off, 1= the LCD display on Launchpad will display ALL of one node data - DISCONNECT ALL BUT ONE node!!! (can be used for quick test of BM boards)
#if DATALOGGER_MODE
    #define DKBLOCK 0
    #define CC1310_LAUNCHPAD 1
#else
    #define CC1310_LAUNCHPAD 0      // define as non-zero if you wanna compile CC1310_LAUNCHPAD code
    #define DKBLOCK 1               // use DKBLOCK to use new DK specific code to make it easy to go back and use new TI code when new SDKs come out
#endif
// ***note to run SPI0 you must turn off DATALOGGER*** and if you run DATALOGGER, DKBLOCK code must be off

#define DEBUG_PRINT 1         // 1= debug print 0= no print

#include "Board.h"
#include <ti/drivers/PIN.h>


uint8_t latestNodeAddress;
bool DK_Mode;        // 1= chg/disc 0=sleep

uint16_t latestADCHiCell;
uint16_t latestADCLoCell;

uint8_t Hottest_Sensor_DegCoff40;            // hottest NTC in all blocks (with +40C bias)
uint8_t Coldest_Sensor_DegCoff40;            // coolest NTC

uint8_t DK_Version;                                 // latest DK version
uint8_t unused8bitvar;                                   // unused for now...

uint8_t latestCapSwitch;



#if DKBLOCK




// generic defines
#define ON  1
#define OFF 0

// I/O port defines
#define LO_FAN_CNTRL    IOID_13   // Future - NOT USED Feb 2021
#define HI_FAN_CNTRL    IOID_14    // only fan drive on board Feb 2021
#define GREEN_LED       IOID_6
//#define YELLOW_LED      IOID_7
#define RED_LED         IOID_5
//#define NODE_ACTIVITY_LED   GREEN_LED     // redefine TI code for our green led

// NTC constants (remember ref is 4.1V not 3.3V)
//#define SHORTED_NTC 20;     // ADC counts for 140C - NTC does not fail in this way, so save value
//#define OPEN_NTC 3008      // open NTC (or colder than -40C which 3007 ADC counts)
#define NTC_OFFSET 40       // 40C added to sent data so that we don't need to use floating point or signed types
#define AMBIENT_TEMP (25+NTC_OFFSET)   // ambient temp of 25C is about 1048 ADC counts
#define NTC_WARM  (35+NTC_OFFSET)          // 35C +40 offset
#define NTC_OVERTEMP (100+40)           // 100C is getting too hot


// declare BlockMode types - 3 basic modes. Either sleeping most of the time, or CHG or DISCH
#define SLEEPING 0
#define CHARGING  10
#define DISCHARGING  20
#define MODE0 30     // temporary rename when have english names

// cell types and balance methods (top balance is not optional)
#define LG_MH1 0          // 3200mah
#define SANYO_NCR18650B 10  // 3400mah  NOTE battery with the --NONZERO-- value will be used
#define CELLTYPE0 0        //
#define BOTTOM_BALANCE  1           // 0=no bot balance 1= YES bot balance also


#if LG_MH1
#define VCELL_HVDO_SPEC 4150        // 4.150V (spec is 4.2)
#define VCELL_BALANCE 3950            // top balance point
#define VCELL_LOW_BALANCE 3000           // if used low balance to lvdo
#define VCELL_LVDO_SPEC 2700        // 2.700 (spec is 2.5)
#endif

#if SANYO_NCR18650B
#define VCELL_HVDO_SPEC 4150        // 4.150V (spec is 4.2)
#define VCELL_BALANCE 3950            // top balance point
#define VCELL_LOW_BALANCE 3000           //  if used low balance to lvdo
#define VCELL_LVDO_SPEC 2700        // 2.700 (spec is 2.5)
#endif

#if SAMSUNG_25R
#define Vcell_HVDO_SPEC 4150        // 4.150V (4.2V spec)
#define VCELL_BALANCE 3950            // top balance point
#define VCELL_LOW_BALANCE 3000           //  if used low balance to lvdo
#define VCELL_LVDO_SPEC 2700        // 2.700 (2.5V spec)
#endif


/* ADC conversion global variables */
//uint8_t numOpenNTC ;   // ignore 1 open or ...
uint16_t resultMv_HI;      // calibrated analog value from hi side
uint16_t resultMv_LO;      // calibrated analog value from lo side
uint8_t latestCapSwitchHit;        // 1= YES hit, 0 = NO
//uint8_t  Hottest_Sensor_DegCoff40; // ambient +40 deg offset (so that we can measure -40 without using unsigned)
//uint8_t  Coldest_Sensor_DegCoff40;   // coldest sensor with 40C offset


bool DK_Mode;        // 1= chg/disc 0=sleep
uint8_t FaultMode;      // overtemp, and NTC open ...more to come

bool latestHIGHshunt;       // value of on or off for high shunt
bool latestLOWshunt;
bool latestFAN;             // value on/off
bool latestRedLED;
bool latestYellowLED;
bool latestGreenLED;

uint8_t latestNodeAddress;

uint16_t latestADCHiCell;
uint16_t latestADCLoCell;

uint8_t Hottest_Sensor_DegCoff40;            // hottest NTC in all blocks (with +40C bias)
uint8_t Coldest_Sensor_DegCoff40;            // coolest NTC

uint8_t DK_Version;                                 // latest DK version
uint8_t unused8bitvar;                                   // unused for now...

uint8_t latestCapSwitch;                                     // cap switch







// function defines
void LED_driver(uint8_t DK_Mode);            // operate the LEDs
//void SPI_Task_Init(void);       /// operate SPI


#endif  // endif DKBLOCK
