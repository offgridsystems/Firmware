/*
 * dkboards.c
 *
 *  Created on: Feb 16, 2021
 *      Author: Tim Economu
 *
 *
 *
 *
 *
 *   Date       Ver     Who     Was/IS
 *
 *   TBD   000     TBE     Released early working version to github
 *   5MAR2021   000     TBE     Created for V2 DKblock hardware using CC1310 Launchpad and RF node and concentrator (using CC13152P-2 dev kit as concentrator)
 *
 */

#define DKBLOCK 1
#if DKBLOCK

#include <dk-concentrator.h>

#include <ti/devices/DeviceFamily.h>

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

/* POSIX Header files */
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>


#include <ti/drivers/GPIO.h>
#include <ti/display/Display.h>


 //*  ======== DK uart task ========


/* Driver Header files */
#include <ti/drivers/UART.h>

/* Example/Board Header files */
#include "Board.h"

/*
 *  ======== uartThread ========
 */
void *uartThread(void *arg0)    // send to arduino (teensy 3.x) via SCI uart port
{
    UART_Handle uartHandle;
    UART_Params uartParams;

    /* Call driver init functions */
    GPIO_init();
    UART_init();

    /* Configure the LED pin */
    GPIO_setConfig(Board_GPIO_LED0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Turn on user LED */
    GPIO_write(Board_GPIO_LED0, Board_GPIO_LED_ON);

    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
//    uartParams.readDataMode = UART_DATA_BINARY;
//    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.readEcho = UART_ECHO_OFF;
    uartParams.baudRate = 1000000;
    //UART_MODE_BLOCKING;

    uartHandle = UART_open(Board_UART0, &uartParams);

    if (uartHandle == NULL) {
        /* UART_open() failed */
       // while (1); // NEVER HANG!!! JUST PRINT FAULT and turn on red led
    }

    // Node address
      char buffer[] = "2B";       // reserve uint8_t in buffer
      uint8_t uint8_buffer = latestNodeAddress;          // load BMS var
       // put var into buffer for transmit
      snprintf(buffer, 4, "%d", uint8_buffer);
      UART_write(uartHandle, buffer, sizeof(buffer));

    // Hiside cell voltage
       char buffer2[] = "2B2B";     // reserv uint16 in buffer
       uint16_t uint16_buffer = latestADCHiCell;
       snprintf(buffer2, 5, "%d", uint16_buffer);
       UART_write(uartHandle, buffer2, sizeof(buffer2));

     // Hottest sensor in degC (+40 offset)
        uint8_buffer = Hottest_Sensor_DegCoff40;
        // put var into buffer for transmit
        snprintf(buffer, 4, "%d", uint8_buffer);
        UART_write(uartHandle, buffer, sizeof(buffer));

        // Coldest sensor in degC  (+40 offset)
            uint8_buffer = Coldest_Sensor_DegCoff40;
            // put var into buffer for transmit
            snprintf(buffer, 4, "%d", uint8_buffer);
            UART_write(uartHandle, buffer, sizeof(buffer));

            // Loside cell voltage
            //char buffer2[] = "2B2B";     // reserv uint16 in buffer
             uint16_buffer = latestADCLoCell;
            snprintf(buffer2, 5, "%d", uint16_buffer);
            UART_write(uartHandle, buffer2, sizeof(buffer2));

            // DK_Version
            uint8_buffer = DK_Version;
            // put var into buffer for transmit
             snprintf(buffer, 4, "%d", uint8_buffer);
             UART_write(uartHandle, buffer, sizeof(buffer));

             // Unused
             uint8_buffer = unused8bitvar;
             // put var into buffer for transmit
              snprintf(buffer, 4, "%d", uint8_buffer);
              UART_write(uartHandle, buffer, sizeof(buffer));

              // Cap switch on block
               uint8_buffer = latestCapSwitch;
               // put var into buffer for transmit
                snprintf(buffer, 4, "%d", uint8_buffer);
                UART_write(uartHandle, buffer, sizeof(buffer));

                //SEND 9999 as end of comm packet
                //char buffer2[] = "2B2B";     // reserv uint16 in buffer
                //uint16_buffer = 65,535;
                uint16_buffer = 9999;
                snprintf(buffer2, 5, "%d", uint16_buffer);
                UART_write(uartHandle, buffer2, sizeof(buffer2));

                // Change byte number 12 to checksum byte - calc checksum
                // calc checksum
                uint32_t checksum;
                checksum = (latestNodeAddress + latestADCHiCell + Hottest_Sensor_DegCoff40 + Coldest_Sensor_DegCoff40 + latestADCLoCell + DK_Version + unused8bitvar + latestCapSwitch);
      //          char uint32_buffer = checksum;   // 32 bit checksum
      //          snprintf(buffer2, 6, "%d", uint16_buffer);
      //          UART_write(uartHandle, buffer2, sizeof(buffer2));



      GPIO_write(Board_GPIO_LED0, Board_GPIO_LED_OFF);


      // Do a UART close here to clean up
      UART_close(uartHandle);

      // DK super expects float and uint16 data types, so do conversion so that super does not have to...
//      DK SUPER STRUCT for receiving data from blocks
//        **** NOTE THAT NODE NUMBER IS RECIEVED/SENT (var is 'from') FIRST ****
//      struct DATA {
//      float sCellV_Hiside;       // high voltage side cells of dkblock
//      uint16_t sThottest;        // hottest NTC counts (lower is hotter)
//      uint16_t sTcoldest;        // coldtest NTC counts
//      float sCellV_Loside ;      // Low voltage side cells
//      float schecksum;                // checksum for data integrity
//    };





      return(NULL);
}


#endif //DKBLOCK

