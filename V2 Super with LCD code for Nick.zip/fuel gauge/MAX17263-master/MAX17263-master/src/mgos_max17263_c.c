#include <stdbool.h>

bool mgos_MAX17263_init(void) {
  return true;
}
