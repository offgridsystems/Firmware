/*
 * Copyright (c) 2015-2019, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/***** Includes *****/
// dk board stuff
#ifndef DKBLOCK
#include <dkboards.h>
#endif

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>



/* BIOS Header files */ 
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Event.h>
#include <ti/sysbios/knl/Clock.h>

/* TI-RTOS Header files */ 
#include <ti/drivers/PIN.h>
//#if CC1310_LAUNCHPAD
#include <ti/display/Display.h>
#include <ti/display/DisplayExt.h>
//#endif

#include <ti/devices/DeviceFamily.h>
#include DeviceFamily_constructPath(driverlib/cpu.h)

/* Board Header files */
#include "Board.h"

/* Application Header files */ 
#include "SceAdc.h"
#include "NodeTask.h"
#include "NodeRadioTask.h"

#ifdef FEATURE_BLE_ADV
#include "ble_adv/BleAdv.h"
#endif

/***** Defines *****/
#define NODE_TASK_STACK_SIZE 1024
#define NODE_TASK_PRIORITY   3

#define NODE_EVENT_ALL                  0xFFFFFFFF
#define NODE_EVENT_NEW_ADC_VALUE    (uint32_t)(1 << 0)
#define NODE_EVENT_UPDATE_LCD       (uint32_t)(1 << 1)


#if CC1310_LAUNCHPAD
/* A change mask of 0xFF0 means that changes in the lower 4 bits does not trigger a wakeup. Old DKblock used delta = 10mv to change mode */
//#define NODE_ADCTASK_CHANGE_MASK                    0xFF0     // each count equals ~2mv so 16 = 32 mv
/* Minimum slow Report interval is 50s (in units of samplingTime)*/
#define NODE_ADCTASK_REPORTINTERVAL_SLOW                50
/* Minimum fast Report interval is 5s (in units of samplingTime) for 30s*/
#define NODE_ADCTASK_REPORTINTERVAL_FAST                5
#define NODE_ADCTASK_REPORTINTERVAL_FAST_DURIATION_MS   30000 //30000
#endif
#if DKBLOCK
/* A change mask of 0xFF0 means that changes in the lower 4 bits does not trigger a wakeup. Old DKblock used delta = 10mv/cell to change mode, so this is block voltage so use 20mv */
// the higher the mask value, the more sensitive the ADC is to changes in value.
#define NODE_ADCTASK_CHANGE_MASK                    0xF00
//#define NODE_ADCTASK_CHANGE_MASK                    0xFE0     // each count equals ~2mv so 16 = 32 mv
//#define NODE_ADCTASK_CHANGE_MASK                    0xFFA       // = 5 so about 10mv
#define SENSITIVE_NODE_ADCTASK_CHANGE_MASK                    0xFFD       // = 2 so more than 4mv per second
//#define SENSITIVE_NODE_ADCTASK_CHANGE_MASK          0xFFF       // basically any change over one second
/* Minimum slow Report interval is 1s (in units of samplingTime)*/
#define NODE_ADCTASK_REPORTINTERVAL_SLOW              10 // sec
/* Minimum fast Report interval is 1s (in units of samplingTime) for 30s*/
#define NODE_ADCTASK_REPORTINTERVAL_FAST               2 // sec

#define NODE_ADCTASK_REPORTINTERVAL_FAST_DURIATION_MS   30000 //30000 = 30 sec??
#endif





#define NUM_EDDYSTONE_URLS      5

/***** Variable declarations *****/
static Task_Params nodeTaskParams;
Task_Struct nodeTask;    /* Not static so you can see in ROV */
static uint8_t nodeTaskStack[NODE_TASK_STACK_SIZE];
Event_Struct nodeEvent;  /* Not static so you can see in ROV */
static Event_Handle nodeEventHandle;
#if CC1310_LAUNCHPAD
static uint16_t latestAdcValue;
#endif
#if DKBLOCK
static uint16_t latestAdcValue;
uint16_t latestAdcValueFromVcellHI;     // highside cell voltage in mV
uint16_t latestAdcValueFromVcellLO;     // lowside 3.7V cell in mV
uint8_t latestAdcValueFromTcellHI;      // highest temperature in DK in C
uint16_t latestAdcValueFromTcellLO;     // lowest temperature in DK incl ambient in C
#endif

/* Clock for the fast report timeout */
Clock_Struct fastReportTimeoutClock;     /* not static so you can see in ROV */
static Clock_Handle fastReportTimeoutClockHandle;

/* Pin driver handle */
#if CC1310_LAUNCHPAD
static PIN_Handle buttonPinHandle;
static PIN_State buttonPinState;
static PIN_Handle ledPinHandle;
static PIN_State ledPinState;
#endif

#if DKBLOCK
static PIN_Handle ledPinHandle;     // LED from Launchpad- also on DK
static PIN_State ledPinState;
static  PIN_Handle PinHandle;      // output pins
static  PIN_State PinState;
#endif


/* Display driver handles */
static Display_Handle hDisplayLcd;
static Display_Handle hDisplaySerial;

#ifdef FEATURE_BLE_ADV
static BleAdv_AdertiserType advertisementType = BleAdv_AdertiserMs;
static const char* urls[NUM_EDDYSTONE_URLS] = {"http://www.ti.com/","http://tinyurl.com/z7ofjy7","http://tinyurl.com/jt6j7ya","http://tinyurl.com/h53v6fe","http://www.ti.com/TI154Stack"};
static uint8_t eddystoneUrlIdx = 0;
#endif

/* Enable the LEDS */
PIN_Config pinTable[] = {
#if CC1310_LAUNCHPAD
#if !defined Board_CC1350STK
    NODE_ACTIVITY_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,  // led
    PIN_TERMINATE
#endif
#endif

#if DKBLOCK
// enable LED pins
        GREEN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,     // green led
        YELLOW_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,     // Yelllow LED
        RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
        PIN_TERMINATE
#endif
};

#if CC1310_LAUNCHPAD
/*
 * Application button pin configuration table:
 *   - Buttons interrupts are configured to trigger on falling edge.
 */
PIN_Config buttonPinTable[] = {
    Board_PIN_BUTTON0  | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
#ifdef FEATURE_BLE_ADV
    Board_PIN_BUTTON1  | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
#endif
    PIN_TERMINATE
};
#endif

#if DKBLOCK
    /* Enable the I/O ports on DK board */
    PIN_Config portTable[] = {
       LO_FAN_CNTRL | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MED,
       HI_FAN_CNTRL | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MED,
       HI_SHUNT_CNTRL | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MED,
       LO_SHUNT_CNTRL | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MED,
       PIN_TERMINATE
     };
#endif


static uint8_t nodeAddress = 0;

#ifdef FEATURE_BLE_ADV
static BleAdv_Stats bleAdvStats = {0};
#endif

/***** Prototypes *****/
static void nodeTaskFunction(UArg arg0, UArg arg1);
static void updateLcd(void);
static void fastReportTimeoutCallback(UArg arg0);

#if CC1310_LAUNCHPAD
static void buttonCallback(PIN_Handle handle, PIN_Id pinId);
static void adcCallback(uint16_t adcValue);
#endif

#if DKBLOCK
static void adcCallback(uint16_t adcValue, uint16_t adcNew, uint8_t adcCap);
#endif

void NodeTask_init(void)
{

    /* Create event used internally for state changes */
    Event_Params eventParam;
    Event_Params_init(&eventParam);
    Event_construct(&nodeEvent, &eventParam);
    nodeEventHandle = Event_handle(&nodeEvent);

    /* Create clock object which is used for fast report timeout */
    Clock_Params clkParams;
    Clock_Params_init(&clkParams);

    clkParams.period = 0;
    clkParams.startFlag = FALSE;
    Clock_construct(&fastReportTimeoutClock, fastReportTimeoutCallback, 1, &clkParams);
    fastReportTimeoutClockHandle = Clock_handle(&fastReportTimeoutClock);

    /* Create the node task */
    Task_Params_init(&nodeTaskParams);
    nodeTaskParams.stackSize = NODE_TASK_STACK_SIZE;
    nodeTaskParams.priority = NODE_TASK_PRIORITY;
    nodeTaskParams.stack = &nodeTaskStack;
    Task_construct(&nodeTask, nodeTaskFunction, &nodeTaskParams, NULL);




}

#ifdef FEATURE_BLE_ADV
void NodeTask_advStatsCB(BleAdv_Stats stats)
{
    memcpy(&bleAdvStats, &stats, sizeof(BleAdv_Stats));

    /* Post LCD update event */
    Event_post(nodeEventHandle, NODE_EVENT_UPDATE_LCD);
}
#endif

static void nodeTaskFunction(UArg arg0, UArg arg1)
{
    /* Initialize display and try to open both UART and LCD types of display. */
    Display_Params params;
    Display_Params_init(&params);
    params.lineClearMode = DISPLAY_CLEAR_BOTH;

    /* Open both an available LCD display and an UART display.
     * Whether the open call is successful depends on what is present in the
     * Display_config[] array of the board file.
     *
     * Note that for SensorTag evaluation boards combined with the SHARP96x96
     * Watch DevPack, there is a pin conflict with UART such that one must be
     * excluded, and UART is preferred by default. To display on the Watch
     * DevPack, add the precompiler define BOARD_DISPLAY_EXCLUDE_UART.
     */
    hDisplayLcd = Display_open(Display_Type_LCD, &params);
    hDisplaySerial = Display_open(Display_Type_UART, &params);

    /* Check if the selected Display type was found and successfully opened */
    if (hDisplaySerial)
    {
        Display_printf(hDisplaySerial, 0, 0, "Waiting for SCE ADC reading...");
    }

    /* Check if the selected Display type was found and successfully opened */
    if (hDisplayLcd)
    {
        Display_printf(hDisplayLcd, 0, 0, "Waiting for ADC...");
    }

    /* Open LED pins */
    ledPinHandle = PIN_open(&ledPinState, pinTable);
    if (!ledPinHandle)
    {
        System_abort("Error initializing board 3.3V domain pins\n");
    }

    /* Open I/O ports */
#if DKBLOCK
    PinHandle = PIN_open(&PinState, portTable);
#endif

    /* Start the SCE ADC task with 1s sample period and reacting to change in ADC value. */
    SceAdc_init(0x00010000, NODE_ADCTASK_REPORTINTERVAL_FAST, NODE_ADCTASK_CHANGE_MASK);
    SceAdc_registerAdcCallback(adcCallback);
    SceAdc_start();     // start up  Sensor Controller tasks



    /* setup timeout for fast report timeout */
    Clock_setTimeout(fastReportTimeoutClockHandle,
            NODE_ADCTASK_REPORTINTERVAL_FAST_DURIATION_MS * 1000 / Clock_tickPeriod);       // Clock_tickPeriod = 1msec, so this is one second timeout


    /* Start fast report and timeout */
    Clock_start(fastReportTimeoutClockHandle);


#if CC1310_LAUNCHPAD
  buttonPinHandle = PIN_open(&buttonPinState, buttonPinTable);
    if (!buttonPinHandle)
    {
        System_abort("Error initializing button pins\n");
    }
    /* Setup callback for button pins */
    if (PIN_registerIntCb(buttonPinHandle, &buttonCallback) != 0)
    {
        System_abort("Error registering button callback function");
    }
#endif


    // main loop is here
    while (1)
    {
        /* Wait for event */
        uint32_t events = Event_pend(nodeEventHandle, 0, NODE_EVENT_ALL, BIOS_WAIT_FOREVER);

        // Make slow or fast ADC report mode depending on whether connected to super or not.
#if DKBLOCK
        if (PackSupervisorConnected) SceAdc_setReportInterval(NODE_ADCTASK_REPORTINTERVAL_FAST, SENSITIVE_NODE_ADCTASK_CHANGE_MASK);    // always force fast report when connected to super
        else     SceAdc_setReportInterval(NODE_ADCTASK_REPORTINTERVAL_SLOW, NODE_ADCTASK_CHANGE_MASK);                             // go to sleep = slow report when not connected
#endif



        /* If new ADC value, send this data */
        if (events & NODE_EVENT_NEW_ADC_VALUE) {

#if !defined Board_CC1350STK
#if CC1310_LAUNCHPAD
            /* Toggle activity LED */
            PIN_setOutputValue(ledPinHandle, NODE_ACTIVITY_LED,!PIN_getOutputValue(NODE_ACTIVITY_LED));
#endif


#if DKBLOCK

       // Do ADC cal right after fresh sample here
            ADC_calibration();  //  get voltage samples and cal for accuracy, save results
              latestAdcValue = resultMv_HI;  // read in calibrated Vcell hi
              latestAdcValueFromVcellLO = resultMv_LO;  // read in calibrated Vcell lo
       // Thermistor sampling
            NTC_Thermistor_testing();       // go get temperatures


       // get DK mode chg/disch/sleep and operate fans and balancing shunts
             uint16_t BlockV = resultMv_HI;
             uint16_t LowCellV = resultMv_LO;
             DK_Mode = FindDK_mode(BlockV, LowCellV);

       // YEL/RED LED on/off (all logic is in dkboards.c)
             LED_driver(DK_Mode);
             if (gFaultMode) latestRedLED = ON;      // turn on RED led for fault mode
             else latestRedLED = OFF;
             if (latestRedLED) PIN_setOutputValue(ledPinHandle, RED_LED, ON);
             else PIN_setOutputValue(ledPinHandle, RED_LED, OFF);
             if (latestYellowLED) PIN_setOutputValue(ledPinHandle, YELLOW_LED, ON);
             else PIN_setOutputValue(ledPinHandle, YELLOW_LED, OFF);

       // operate both fan(s) controls
             if (latestFAN){
                 PIN_setOutputValue(PinHandle, LO_FAN_CNTRL, ON); // future external fan?
                 PIN_setOutputValue(PinHandle, HI_FAN_CNTRL, ON);
             }
             else {
                 PIN_setOutputValue(PinHandle, LO_FAN_CNTRL, OFF); // future external fan ??
                 PIN_setOutputValue(PinHandle, HI_FAN_CNTRL, OFF);

             }
       //operate shunt balancers
            if (latestHIGHshunt) PIN_setOutputValue(PinHandle, HI_SHUNT_CNTRL, ON);
            else PIN_setOutputValue(PinHandle, HI_SHUNT_CNTRL, OFF);
            if (latestLOWshunt) PIN_setOutputValue(PinHandle, LO_SHUNT_CNTRL, ON);
            else PIN_setOutputValue(PinHandle, LO_SHUNT_CNTRL, OFF);

            // toggle (if super connected) or blink (in sleep) green led when sending packet
            PIN_setOutputValue(ledPinHandle, GREEN_LED,!PIN_getOutputValue(GREEN_LED));


#endif   // DKBLOCK
#endif  // not Board_CC1350STK

#if CC1310_LAUNCHPAD
            NodeRadioTask_sendAdcData(latestAdcValue);
#endif

#if DKBLOCK
            if (!PackSupervisorConnected) {
                //wait a few micros
                uint16_t i;
                for (i = 0; i < 1000; i++){
                    PIN_setOutputValue(ledPinHandle, GREEN_LED,!PIN_getOutputValue(GREEN_LED));
                }
                PIN_setOutputValue(ledPinHandle, GREEN_LED, OFF);
            }
            NodeRadioTask_sendAdcData(latestAdcValue, latestAdcValueFromVcellLO, latestCapSwitchHit);
            // toggle ON/OFF green led when sending packet if Super is connected, else just have short blink to save power
#endif

            /* Update display */
            updateLcd();
        }
        /* If new ADC value, send this data */
        if (events & NODE_EVENT_UPDATE_LCD) {
            /* update display */
            updateLcd();
        }
    }
}   // end of NodeTask

static void updateLcd(void)
{
#ifdef FEATURE_BLE_ADV
    char advMode[16] = {0};
#endif

    /* get node address if not already done */
    if (nodeAddress == 0)
    {
        nodeAddress = nodeRadioTask_getNodeAddr();
    }

    /* print to LCD */
#if DKBLOCK
    Display_clear(hDisplayLcd);
#endif
    Display_printf(hDisplayLcd, 0, 0, "NodeID: 0x%02x", nodeAddress);
    Display_printf(hDisplayLcd, 1, 0, "ADC(sw): %04d", latestAdcValue);


    /* Print to UART clear screen, put cuser to beggining of terminal and print the header */
    Display_printf(hDisplaySerial, 0, 0, "\033[2J \033[0;0HNode ID: 0x%02x", nodeAddress);
    Display_printf(hDisplaySerial, 0, 0, "Node ADC Reading: %04d", latestAdcValue);
#if DKBLOCK
    Display_printf(hDisplaySerial, 0, 0, "Node CAP sw: %03d", latestCapSwitchHit);
#endif
#ifdef FEATURE_BLE_ADV
    if (advertisementType == BleAdv_AdertiserMs)
    {
         strncpy(advMode, "BLE MS", 6);
    }
    else if (advertisementType == BleAdv_AdertiserUrl)
    {
         strncpy(advMode, "Eddystone URL", 13);
    }
    else if (advertisementType == BleAdv_AdertiserUid)
    {
         strncpy(advMode, "Eddystone UID", 13);
    }
    else
    {
         strncpy(advMode, "None", 4);
    }

    /* print to LCD */
    Display_printf(hDisplayLcd, 2, 0, "Adv Mode:");
    Display_printf(hDisplayLcd, 3, 0, "%s", advMode);
    Display_printf(hDisplayLcd, 4, 0, "Adv successful | failed");
    Display_printf(hDisplayLcd, 5, 0, "%04d | %04d",
                   bleAdvStats.successCnt + bleAdvStats.failCnt);

    /* print to UART */
    Display_printf(hDisplaySerial, 0, 0, "Advertiser Mode: %s", advMode);
    Display_printf(hDisplaySerial, 0, 0, "Advertisement success: %d out of %d",
                   bleAdvStats.successCnt,
                   bleAdvStats.successCnt + bleAdvStats.failCnt);
#endif
}

    /* Save latest value */
#if CC1310_LAUNCHPAD
    static void adcCallback(uint16_t adcValue)
    {
    latestAdcValue = adcValue;
    /* Post event */
     Event_post(nodeEventHandle, NODE_EVENT_NEW_ADC_VALUE);
 }
#endif

#if DKBLOCK
    static void adcCallback(uint16_t adcValue, uint16_t adcNew, uint8_t adcCap)
    {
    latestAdcValue = adcValue;
    latestAdcValueFromVcellLO = adcNew;
    latestCapSwitchHit = adcCap ;
    /* Post event */
     Event_post(nodeEventHandle, NODE_EVENT_NEW_ADC_VALUE);
 }
#endif





/*
 *  ======== buttonCallback ========
 *  Pin interrupt Callback function board buttons configured in the pinTable.
 */

#if CC1310_LAUNCHPAD
static void buttonCallback(PIN_Handle handle, PIN_Id pinId)
{
    /* Debounce logic, only toggle if the button is still pushed (low) */
    CPUdelay(8000*50);


    if (PIN_getInputValue(Board_PIN_BUTTON0) == 0)
    {
        //start fast report and timeout
       SceAdc_setReportInterval(NODE_ADCTASK_REPORTINTERVAL_FAST, NODE_ADCTASK_CHANGE_MASK);
       Clock_start(fastReportTimeoutClockHandle);
    }
#ifdef FEATURE_BLE_ADV
    else if (PIN_getInputValue(Board_PIN_BUTTON1) == 0)
    {
        if (advertisementType != BleAdv_AdertiserUrl)
        {
            advertisementType++;
        }

        //If URL then cycle between url[0 - num urls]
        if (advertisementType == BleAdv_AdertiserUrl)
        {
            if (eddystoneUrlIdx < NUM_EDDYSTONE_URLS)
            {
                //update URL
                BleAdv_updateUrl(urls[eddystoneUrlIdx++]);
            }
            else
            {
                //last URL, reset index and increase advertiserType
                advertisementType++;
                eddystoneUrlIdx = 0;
            }
        }

        if (advertisementType == BleAdv_AdertiserTypeEnd)
        {
            advertisementType = BleAdv_AdertiserNone;
        }

        //Set advertisement type
        BleAdv_setAdvertiserType(advertisementType);

        /* update display */
        Event_post(nodeEventHandle, NODE_EVENT_UPDATE_LCD);

        //start fast report and timeout
        SceAdc_setReportInterval(NODE_ADCTASK_REPORTINTERVAL_FAST, NODE_ADCTASK_CHANGE_MASK);
        Clock_start(fastReportTimeoutClockHandle);
    }
#endif
}
#endif // CC1310_LAUNCHPAD




static void fastReportTimeoutCallback(UArg arg0)
{
    SceAdc_setReportInterval(NODE_ADCTASK_REPORTINTERVAL_SLOW, NODE_ADCTASK_CHANGE_MASK);
}
